import Layout from "../components/layout/Layout";

export default function NotFound() {
  return (
    <Layout headerTitle="Not Found">
      <h1>This is Not Found page</h1>
    </Layout>
  );
}
