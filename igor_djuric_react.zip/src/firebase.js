// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAsTSvcaTi47wkDOQ7HUeUMits9Ydt7yps",
  authDomain: "notes-app-8b70b.firebaseapp.com",
  projectId: "notes-app-8b70b",
  storageBucket: "notes-app-8b70b.appspot.com",
  messagingSenderId: "317520154736",
  appId: "1:317520154736:web:cbe4dae774394d505d24b5"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);