export function isEmpty(value) {
  if (value.length === 0) {
    return true;
  }
  return false;
}
