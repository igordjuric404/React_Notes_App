import "./styles.scss";

export default function Footer() {
  return (
    <div className="footer">
      <div>
        <p>Powered by React Class</p>
      </div>
    </div>
  );
}
