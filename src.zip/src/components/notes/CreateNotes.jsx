import "../../styles/main.scss";
import ListNotes from "../../components/notes/ListNotes";
import { useState } from "react";
import axios from "axios";
import Swal from "sweetalert2";
import { isEmpty } from "../../services/Validation";
import { useEffect } from "react";
import { Link } from "react-router-dom";

export default function CreateNotes() {
  // States
  const [notes, setNotes] = useState([]);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [showListNotes, setShowListNotes] = useState(false); // New state to manage ListNotes rendering
  const [postsFetched, setPostsFetched] = useState(false); // New state to track if posts have been fetched

  // Use effect hook to fetch posts when button for showing random posts is clicked (showListNotes is true) and posts have not been fetched yet
  useEffect(() => {
    // Fetch random posts from an API and update the notes state
    const getPosts = () => {
      axios
        .get("https://jsonplaceholder.typicode.com/posts")
        .then((response) => {
          const fetchedPosts = response.data;
          setNotes([...notes, ...fetchedPosts]); // Merge the existing notes with the fetched posts
          setPostsFetched(true);
        });
    };

    if (showListNotes && !postsFetched) {
      getPosts(); // Fetch posts only when showListNotes is true and notes array is empty
    }
  }, [showListNotes, postsFetched, notes]);

  // Fetch random posts from an API and update the notes state
  // const getPosts = () => {
  //   axios.get("https://jsonplaceholder.typicode.com/posts").then((response) => {
  //     const fetchedPosts = response.data;
  //     setNotes([...notes, ...fetchedPosts]); // Merge the existing notes with the fetched posts
  //     setPostsFetched(true);
  //   });
  // };

  // // Use effect hook to fetch posts when button for showing random posts is clicked (showListNotes is true) and posts have not been fetched yet
  // useEffect(() => {
  //   if (showListNotes && !postsFetched) {
  //     getPosts();
  //   }
  // }, [showListNotes, postsFetched]);

  // Function to create a new note
  const createNote = () => {
    // Validation for title and body
    if (isEmpty(title)) {
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Title cannot be empty",
      });
      return;
    }

    if (isEmpty(body)) {
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Content cannot be empty",
      });
      return;
    }

    // Create a new note object and add it to the notes state
    let newNote = {
      id: notes.length + 1,
      title: title,
      body: body,
    };
    setNotes([...notes, newNote]);
  };

  // Function to remove a note
  const removeNote = (noteId) => {
    Swal.fire({
      title: "Are you sure?",
      text: "You are going to delete this note",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.isConfirmed) {
        // Filter out the note with the given noteId and update the notes state
        let updatedNotes = notes.filter((note) => {
          return note.id !== noteId;
        });
        setNotes(updatedNotes);
        Swal.fire(
          "Deleted!",
          "You have successfully deleted the note",
          "success",
        );
      }
    });
  };

  // Function to toggle the display of ListNotes
  const renderListNotes = () => {
    setShowListNotes(true);
  };

  // JSX rendering
  return (
    <>
      <div className="create-wrapper">
        <input
          onChange={(e) => setTitle(e.target.value)}
          type="text"
          placeholder="Add note title"
        />
        <input
          onChange={(e) => setBody(e.target.value)}
          type="text"
          placeholder="Add note content"
        />
        {/* Button to create a new note */}
        <button onClick={createNote}>create</button>
        {/* Button to fetch and show random posts */}
        {!postsFetched && (
          <button onClick={renderListNotes}>Create random posts</button>
        )}
      </div>

      {/* Conditional rendering based on the length of notes */}
      {notes.length === 0 ? (
        <>
          <h3 style={{ textAlign: "center", color: "#fff" }}>0 notes</h3>
        </>
      ) : (
        <>
          {/* Render ListNotes component with notes */}
          <ListNotes notes={notes.slice().reverse()} removeNote={removeNote} />
        </>
      )}
    </>
  );
}
