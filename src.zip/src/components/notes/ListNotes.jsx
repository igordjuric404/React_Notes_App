import React from "react";
import { Link } from "react-router-dom";
import Note from "./Note";

export default function ListNotes({ notes, removeNote }) {
  return (
    <div className="main">
      {notes.map((note, index) => {
        return (
          <Note
            key={index}
            id={note.id}
            title={note.title}
            body={note.body}
            removeNote={removeNote}
          />
        );
      })}
    </div>
  );
}
