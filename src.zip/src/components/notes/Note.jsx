import { Link } from "react-router-dom";
import Remove from "../../images/close.png";
import "./styles.scss";

export default function Note({ id, title, body, removeNote }) {
  return (
    <div className="note">
      <Link to={`/note/${id}`}>
        <div className="note-wrapper">
          <img
            onClick={() => {
              removeNote(id);
            }}
            className="remove-note"
            src={Remove}
            alt=""
          />
          <h4 className="title">{title.substring(0, 40)}</h4>
          <p className="body">{body.substring(0, 200)}</p>
        </div>
      </Link>
    </div>
  );
}
