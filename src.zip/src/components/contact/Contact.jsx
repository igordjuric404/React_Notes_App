import React, { useState } from "react";
import Swal from "sweetalert2";
import "./styles.scss";

const Contact = () => {
  const [responses, setResponses] = useState([]);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [question, setQuestion] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();

    // Check for empty inputs
    if (name.trim() === "" || email.trim() === "" || question.trim() === "") {
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "All inputs must be filled",
      });
      return;
    }

    // Validate email format
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Please enter a valid email address",
      });
      return;
    }

    const id = responses.length + 1;
    const newResponse = {
      id: id,
      name: name,
      email: email,
      question: question,
    };
    setResponses([...responses, newResponse]);
    setSubmitted(true);
  };

  return (
    <div className="contact-container">
      {submitted ? (
        <div>
          <h2>Thank you for contacting us!</h2>
          <p>
            Your information has been received. Here are the details you
            provided:
          </p>
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Question</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>{name}</td>
                <td>{email}</td>
                <td>{question}</td>
              </tr>
            </tbody>
          </table>
        </div>
      ) : (
        <form className="contact-form" onSubmit={handleSubmit}>
          <div>
            <label htmlFor="name">Name:</label>
            <input
              type="text"
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div>
            <label htmlFor="email">Email:</label>
            <input
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div>
            <label htmlFor="question">Question:</label>
            <textarea
              id="question"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
            />
          </div>
          <button type="submit">Submit</button>
        </form>
      )}
    </div>
  );
};

export default Contact;
