import "./styles.scss";
import { Link } from "react-router-dom";
export default function Header(props) {
  return (
    <div className="header">
      <div className="header-logo">
        <img
          src="https://bluegrid.io/wp-content/themes/bluegrid/images/bluegrid-logo.svg?x55882"
          alt=""
        />
      </div>
      <div className="header-title">
        <h1>{props.headerTitle}</h1>
      </div>
      <div className="header-nav">
        <nav className="nav">
          <Link to="/">Home</Link>
          <Link to="/about-us">About us</Link>
          <Link to="/contact">Contact</Link>
        </nav>
      </div>
    </div>
  );
}
