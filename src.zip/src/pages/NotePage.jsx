import React from "react";
import Layout from "../components/layout/Layout";
import { useParams } from "react-router-dom";

export default function NotePage({ notes }) {
  const { id } = useParams();
  const note = notes.find((note) => note.id === parseInt(id));

  return (
    <Layout headerTitle="Note no:">
      <div>
        {note ? (
          <>
            <h2>{note.title}</h2>
            <p>{note.body}</p>
          </>
        ) : (
          <p>Note not found.</p>
        )}
      </div>{" "}
    </Layout>
  );
}
