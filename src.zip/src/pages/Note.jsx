import React from "react";
import Layout from "../components/layout/Layout";

export default function Note() {
  return (
    <Layout headerTitle="Note">
      <h1>This is the Note page</h1> //ovo je bila stranica samo za testiranje ruta u pocetku
    </Layout>
  );
}
